package com.example.orefarm;

/** Things that only the client does. The server uses this empty version. */
public class CommonProxy {

    public void init() {
    }

    public void openRecipeBook() {
    }
}
