package com.example.orefarm;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.item.ItemStack;

/** The recipes shown in the Ore Farm recipe book. OreFarmMod fills this in next to the real crafting recipes. */
public class RecipeBookData {

    public static class Entry {
        public final ItemStack output;
        public final ItemStack[] grid;   // 9 cells, row by row (null = empty)
        public final String[] lines;     // short explanation under the grid

        public Entry(ItemStack output, ItemStack[] grid, String... lines) {
            this.output = output;
            this.grid = grid;
            this.lines = lines;
        }
    }

    private static final List<Entry> ENTRIES = new ArrayList<Entry>();

    public static void add(Entry entry) {
        ENTRIES.add(entry);
    }

    public static List<Entry> all() {
        return ENTRIES;
    }
}
