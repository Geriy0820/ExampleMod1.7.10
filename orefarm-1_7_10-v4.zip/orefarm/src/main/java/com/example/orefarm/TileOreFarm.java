package com.example.orefarm;

import net.minecraft.block.Block;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.inventory.InventoryLargeChest;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.EnumChatFormatting;
import net.minecraftforge.common.util.ForgeDirection;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

public class TileOreFarm extends TileEntity {

    /** Every this-many upgrades the speed/Fortune multiplier doubles AND the Farm Core cost doubles. */
    public static final int DOUBLE_EVERY = 10;

    /** Block textures per farm (t1..t5). The levels are spread over these. */
    public static final int STAGES = 5;

    /** Levels above this give no extra effect. It only keeps the maths from overflowing; nobody gets here. */
    private static final int EFFECT_LEVEL_CAP = 2000;

    /** Iron and gold ore drop themselves; with this on, the farm hands out ingots instead (no furnace needed). */
    private static final boolean AUTO_SMELT = true;

    /** Let Fortune multiply those ingots too (vanilla Fortune does nothing for iron/gold ore). */
    private static final boolean FORTUNE_BOOSTS_INGOTS = true;

    /** A farm holds this many items, plus this many more for every level. */
    private static final long BASE_CAPACITY = 2048L;

    /** Breaking a farm spills at most this many item stacks (the rest is lost, so the game can't be flooded). */
    private static final int MAX_STACKS_DROPPED = 128;

    /** Most item moves per second into one neighbouring chest/hopper (stops lag with bottomless inventories). */
    private static final int MAX_MOVES_PER_PUSH = 512;

    private int level = -1;        // upgrades applied; -1 = saved by an older version (fixed up in updateEntity)
    private double progress;       // mining progress; one "mining" happens each time it passes the ore's base time
    private ItemStack bufferType;  // what is stored (size 1, just the type)
    private int bufferCount;       // how many are stored

    // ------------------------------------------------------------------ level maths

    public static int clampLevel(int level) {
        return Math.max(0, level);
    }

    public static int clampStage(int stage) {
        return Math.max(0, Math.min(STAGES - 1, stage));
    }

    /** Which texture (0-4) a farm of this level uses. */
    public static int stageFor(int level) {
        if (level >= 100) return 4;
        if (level >= 30) return 3;
        if (level >= 10) return 2;
        return level >= 1 ? 1 : 0;
    }

    /** 1 below level 10, then 2, 4, 8... for every further 10 levels. */
    private static double doublings(int level) {
        return Math.pow(2.0D, Math.min(clampLevel(level), EFFECT_LEVEL_CAP) / DOUBLE_EVERY);
    }

    /** Speed multiplier: +1x per upgrade (1x, 2x ... 10x), then the level number times the doublings (level 10 = 20x, 11 = 22x ...). */
    public static double speedFor(int level) {
        int l = Math.min(clampLevel(level), EFFECT_LEVEL_CAP);
        double base = l < DOUBLE_EVERY ? l + 1 : l;
        return base * doublings(level);
    }

    /** Fortune level: +1 per upgrade (0, 1 ... 9), then the level number times the doublings (level 10 = 20, 11 = 22 ...). */
    public static double fortuneFor(int level) {
        int l = Math.min(clampLevel(level), EFFECT_LEVEL_CAP);
        return l * doublings(level);
    }

    /** Farm Cores needed for upgrade number n (1 = the first upgrade): 1 for upgrades 1-10, 2 for 11-20, 4 for 21-30 ... */
    public static long upgradeCost(int upgrade) {
        if (upgrade < 1) return 0L;
        int doubles = (upgrade - 1) / DOUBLE_EVERY;
        return doubles >= 62 ? Long.MAX_VALUE : (1L << doubles);
    }

    /** How many items a farm of this level can hold inside. */
    public static long capacityFor(int level) {
        return Math.min(BASE_CAPACITY * (clampLevel(level) + 1L), Integer.MAX_VALUE - 1L);
    }

    /** Average drop multiplier of vanilla Fortune: 1x at Fortune 0, about (Fortune + 1) / 2 for higher levels. */
    public static double fortuneMultiplier(double fortune) {
        return (fortune + 1.0D) / 2.0D + 1.0D / (fortune + 2.0D);
    }

    /** base items per mining x number of minings x multiplier, rounded up or down at random so the average stays exact. */
    public static long amountFor(double baseQuantity, double ops, double multiplier, Random rand) {
        double total = baseQuantity * ops * multiplier;
        if (!(total > 0.0D)) return 0L;                       // also catches NaN
        long whole = (long) total;
        if (whole < Long.MAX_VALUE && rand.nextDouble() < total - whole) whole++;
        return whole;
    }

    /** Short number for chat and tooltips: 950, 1.6K, 102.4K, 3.2M ... */
    public static String compact(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v)) return "huge";
        if (v < 1000.0D) {
            return v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.ENGLISH, "%.1f", v);
        }
        String[] units = { "K", "M", "B", "T" };
        double scaled = v;
        int i = -1;
        while (scaled >= 1000.0D && i < units.length - 1) {
            scaled /= 1000.0D;
            i++;
        }
        if (scaled >= 1000.0D) return String.format(Locale.ENGLISH, "%.2e", v);
        return String.format(Locale.ENGLISH, "%.1f", scaled) + units[i];
    }

    // -------------------------------------------------------------------- level

    /** Current upgrade level (also right for an old farm that hasn't ticked yet: its tier is in the metadata). */
    public int getLevel() {
        if (level >= 0) return level;
        if (worldObj != null) return clampLevel(worldObj.getBlockMetadata(xCoord, yCoord, zCoord));
        return 0;
    }

    /** Used when a farm is placed from an item, so it keeps the level it had. */
    public void setLevel(int newLevel) {
        level = clampLevel(newLevel);
        progress = 0.0D;
        showStage();
        markDirty();
    }

    /** One more upgrade (the Farm Cores are taken by the caller). Returns false only at the absolute int limit. */
    public boolean upgrade() {
        int current = getLevel();
        if (current >= Integer.MAX_VALUE) return false;
        level = current + 1;
        showStage();
        markDirty();
        return true;
    }

    /** Keeps the block's metadata (= which texture is drawn) in step with the level. Block metadata only holds 0-15. */
    private void showStage() {
        if (worldObj == null || worldObj.isRemote) return;
        int stage = stageFor(level);
        if (worldObj.getBlockMetadata(xCoord, yCoord, zCoord) != stage) {
            worldObj.setBlockMetadataWithNotify(xCoord, yCoord, zCoord, stage, 3);
        }
    }

    // --------------------------------------------------------------------- tick

    @Override
    public void updateEntity() {
        if (worldObj.isRemote) return;

        Block b = getBlockType();
        if (!(b instanceof BlockOreFarm)) return;
        BlockOreFarm farm = (BlockOreFarm) b;

        if (level < 0) {                       // farm from an older version: its tier was stored in the metadata
            level = getLevel();
            showStage();
            markDirty();
        }

        long capacity = capacityFor(level);
        if (bufferCount < capacity) {
            double baseTicks = farm.getBaseTicks();
            progress += speedFor(level);
            if (progress >= baseTicks) {
                double ops = Math.floor(progress / baseTicks);   // how many "minings" happen this tick
                progress -= ops * baseTicks;
                if (progress < 0.0D) progress = 0.0D;
                produce(farm, ops, capacity);
                markDirty();
            }
        }

        // Try to push stored items out twice a second (spread out so farms don't all fire together)
        if (bufferCount > 0 && (worldObj.getTotalWorldTime() + xCoord + zCoord) % 10L == 0L) {
            pushOut();
        }
    }

    /**
     * Works out what 'ops' minings give in one go. One plain mining is asked from the ore block (so we get the
     * right item), then multiplied by the Fortune bonus. This keeps huge levels fast: no per-item loops.
     */
    private void produce(BlockOreFarm farm, double ops, long capacity) {
        Block ore = farm.getOre();
        ArrayList<ItemStack> drops = ore.getDrops(worldObj, xCoord, yCoord, zCoord, 0, 0);
        double fortune = fortuneFor(level);
        for (ItemStack drop : drops) {
            if (drop == null || drop.stackSize <= 0) continue;
            boolean dropsItself = drop.getItem() == Item.getItemFromBlock(ore);
            ItemStack item = smeltIfNeeded(drop, dropsItself);
            double multiplier = (dropsItself && !FORTUNE_BOOSTS_INGOTS) ? 1.0D : fortuneMultiplier(fortune);
            addToBuffer(item, amountFor(item.stackSize, ops, multiplier, worldObj.rand), capacity);
        }
    }

    /** Ores that drop themselves (iron, gold) are turned into their ingots right away. */
    private static ItemStack smeltIfNeeded(ItemStack drop, boolean dropsItself) {
        if (!AUTO_SMELT || !dropsItself) return drop;     // coal, diamond, etc. are already finished items
        ItemStack smelted = FurnaceRecipes.smelting().getSmeltingResult(drop);
        if (smelted == null) return drop;
        ItemStack result = smelted.copy();
        result.stackSize = drop.stackSize * smelted.stackSize;
        return result;
    }

    // ------------------------------------------------------------------- buffer

    private void addToBuffer(ItemStack drop, long amount, long capacity) {
        if (drop == null || amount <= 0L) return;
        if (bufferType == null) {
            bufferType = drop.copy();
            bufferType.stackSize = 1;
            bufferCount = 0;
        }
        if (bufferType.isItemEqual(drop) && ItemStack.areItemStackTagsEqual(bufferType, drop)) {
            long room = Math.max(0L, capacity - bufferCount);
            bufferCount += (int) Math.min(amount, room);
        }
    }

    /** Hand stored items to a player. Returns how many were given. */
    public int giveTo(EntityPlayer player) {
        int total = 0;
        while (bufferType != null && bufferCount > 0) {
            int take = Math.min(bufferCount, Math.max(1, bufferType.getMaxStackSize()));
            ItemStack out = bufferType.copy();
            out.stackSize = take;
            player.inventory.addItemStackToInventory(out);
            int moved = take - out.stackSize;
            if (moved <= 0) break;
            bufferCount -= moved;
            total += moved;
            if (out.stackSize > 0) break;   // player's inventory is full
        }
        if (bufferCount <= 0) {
            bufferCount = 0;
            bufferType = null;
        }
        if (total > 0) markDirty();
        return total;
    }

    /** Spill what is stored as item entities (used when the block is broken). */
    public void dropBuffer() {
        if (worldObj == null || worldObj.isRemote) return;
        int stacks = 0;
        while (bufferType != null && bufferCount > 0 && stacks < MAX_STACKS_DROPPED) {
            int n = Math.min(bufferCount, Math.max(1, bufferType.getMaxStackSize()));
            ItemStack stack = bufferType.copy();
            stack.stackSize = n;
            worldObj.spawnEntityInWorld(
                    new EntityItem(worldObj, xCoord + 0.5D, yCoord + 0.5D, zCoord + 0.5D, stack));
            bufferCount -= n;
            stacks++;
        }
        bufferCount = 0;
        bufferType = null;
    }

    public String statusLine() {
        Block b = getBlockType();
        if (!(b instanceof BlockOreFarm)) return "";
        BlockOreFarm farm = (BlockOreFarm) b;
        int lvl = getLevel();
        long cost = upgradeCost(lvl + 1);
        String stored = bufferCount >= capacityFor(lvl)
                ? compact(bufferCount) + " (FULL)" : compact(bufferCount);
        return EnumChatFormatting.GOLD + farm.getDisplayName() + " Farm" + EnumChatFormatting.GRAY
                + " | Level " + lvl
                + " | Speed " + compact(speedFor(lvl)) + "x"
                + " | Fortune " + compact(fortuneFor(lvl))
                + " | Stored: " + stored
                + " | Next upgrade: " + compact(cost) + " Farm Core" + (cost == 1L ? "" : "s");
    }

    // ------------------------------------------------------------------- output

    private void pushOut() {
        if (bufferType == null || bufferCount <= 0) return;
        boolean changed = false;

        for (ForgeDirection dir : ForgeDirection.VALID_DIRECTIONS) {
            if (bufferCount <= 0) break;
            int nx = xCoord + dir.offsetX;
            int ny = yCoord + dir.offsetY;
            int nz = zCoord + dir.offsetZ;
            if (!worldObj.blockExists(nx, ny, nz)) continue;

            TileEntity te = worldObj.getTileEntity(nx, ny, nz);
            if (!(te instanceof IInventory)) continue;

            IInventory inv = resolve(te);
            int side = dir.getOpposite().ordinal();   // the face of that inventory touching us

            int moves = 0;
            while (bufferCount > 0 && moves++ < MAX_MOVES_PER_PUSH) {
                int take = Math.min(bufferCount, Math.max(1, bufferType.getMaxStackSize()));
                ItemStack stack = bufferType.copy();
                stack.stackSize = take;
                ItemStack left = insert(inv, stack, side);
                int moved = take - (left == null ? 0 : left.stackSize);
                if (moved <= 0) break;
                bufferCount -= moved;
                changed = true;
                if (left != null) break;            // that inventory is full
            }
        }

        if (bufferCount <= 0) {
            bufferCount = 0;
            bufferType = null;
        }
        if (changed) markDirty();
    }

    /** Treat the two halves of a double chest as one inventory. */
    private IInventory resolve(TileEntity te) {
        if (te instanceof TileEntityChest) {
            ForgeDirection[] horizontal = {
                ForgeDirection.NORTH, ForgeDirection.SOUTH, ForgeDirection.WEST, ForgeDirection.EAST
            };
            for (ForgeDirection d : horizontal) {
                int ox = te.xCoord + d.offsetX;
                int oz = te.zCoord + d.offsetZ;
                if (!worldObj.blockExists(ox, te.yCoord, oz)) continue;
                TileEntity other = worldObj.getTileEntity(ox, te.yCoord, oz);
                if (other instanceof TileEntityChest && other.getBlockType() == te.getBlockType()) {
                    return new InventoryLargeChest("container.chestDouble",
                            (TileEntityChest) te, (TileEntityChest) other);
                }
            }
        }
        return (IInventory) te;
    }

    /** Insert as much of the stack as fits. Returns the leftover (or null if it all fit). */
    private static ItemStack insert(IInventory inv, ItemStack stack, int side) {
        ISidedInventory sided = inv instanceof ISidedInventory ? (ISidedInventory) inv : null;

        int[] slots;
        if (sided != null) {
            slots = sided.getAccessibleSlotsFromSide(side);
        } else {
            slots = new int[inv.getSizeInventory()];
            for (int i = 0; i < slots.length; i++) slots[i] = i;
        }

        for (int slot : slots) {
            if (stack.stackSize <= 0) return null;
            if (!inv.isItemValidForSlot(slot, stack)) continue;
            if (sided != null && !sided.canInsertItem(slot, stack, side)) continue;

            ItemStack existing = inv.getStackInSlot(slot);
            int limit = Math.min(inv.getInventoryStackLimit(), stack.getMaxStackSize());

            if (existing == null) {
                int put = Math.min(limit, stack.stackSize);
                ItemStack placed = stack.copy();
                placed.stackSize = put;
                inv.setInventorySlotContents(slot, placed);
                stack.stackSize -= put;
                inv.markDirty();
            } else if (existing.isItemEqual(stack) && ItemStack.areItemStackTagsEqual(existing, stack)) {
                int put = Math.min(limit - existing.stackSize, stack.stackSize);
                if (put > 0) {
                    existing.stackSize += put;
                    stack.stackSize -= put;
                    inv.markDirty();
                }
            }
        }
        return stack.stackSize > 0 ? stack : null;
    }

    // ---------------------------------------------------------------------- NBT

    @Override
    public void readFromNBT(NBTTagCompound tag) {
        super.readFromNBT(tag);
        level = tag.hasKey("Level") ? clampLevel(tag.getInteger("Level")) : -1;
        progress = tag.getDouble("Progress");              // older saves stored this as a float: still reads fine
        bufferCount = tag.getInteger("Count");
        bufferType = tag.hasKey("Item") ? ItemStack.loadItemStackFromNBT(tag.getCompoundTag("Item")) : null;
        if (bufferType == null) bufferCount = 0;
    }

    @Override
    public void writeToNBT(NBTTagCompound tag) {
        super.writeToNBT(tag);
        if (level >= 0) tag.setInteger("Level", level);
        tag.setDouble("Progress", progress);
        tag.setInteger("Count", bufferCount);
        if (bufferType != null) {
            NBTTagCompound item = new NBTTagCompound();
            bufferType.writeToNBT(item);
            tag.setTag("Item", item);
        }
    }
}
