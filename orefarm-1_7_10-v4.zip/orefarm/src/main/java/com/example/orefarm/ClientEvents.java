package com.example.orefarm;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiCrafting;
import net.minecraftforge.client.event.GuiScreenEvent;

/** Adds a "Recipes" button to the crafting table screen. */
@SideOnly(Side.CLIENT)
public class ClientEvents {

    private static final int BUTTON_ID = 7731;

    @SubscribeEvent
    @SuppressWarnings("unchecked")
    public void onInitGui(GuiScreenEvent.InitGuiEvent.Post event) {
        if (event.gui instanceof GuiCrafting) {
            int left = (event.gui.width - 176) / 2;     // the crafting table screen is always 176 x 166
            int top = (event.gui.height - 166) / 2;
            event.buttonList.add(new RecipeButton(BUTTON_ID, left + 118, top + 6, 52, 16));
        }
    }

    /** Opens the recipe book; "Done" brings you straight back to the crafting table. */
    private static class RecipeButton extends GuiButton {

        RecipeButton(int id, int x, int y, int width, int height) {
            super(id, x, y, width, height, "Recipes");
        }

        @Override
        public boolean mousePressed(Minecraft mc, int mouseX, int mouseY) {
            boolean pressed = super.mousePressed(mc, mouseX, mouseY);
            if (pressed) {
                mc.displayGuiScreen(new GuiRecipeBook(mc.currentScreen));
            }
            return pressed;
        }
    }
}
