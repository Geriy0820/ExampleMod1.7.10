package com.example.orefarm;

import java.util.List;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.item.ItemStack;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

/** A simple recipe viewer: one recipe per page, Prev / Next buttons, Done to close. */
@SideOnly(Side.CLIENT)
public class GuiRecipeBook extends GuiScreen {

    private static final int PANEL_W = 190;
    private static final int PANEL_H = 130;
    private static final int BTN_PREV = 1;
    private static final int BTN_DONE = 2;
    private static final int BTN_NEXT = 3;

    private static final RenderItem ITEM_RENDER = new RenderItem();
    private static int lastPage = 0;       // reopening the book shows the page you were on

    private final GuiScreen parent;        // where "Done" goes back to (null = the game)
    private int page;

    public GuiRecipeBook(GuiScreen parent) {
        this.parent = parent;
        this.page = lastPage;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void initGui() {
        int l = (width - PANEL_W) / 2;
        int y = (height - PANEL_H) / 2 + PANEL_H + 6;
        buttonList.clear();
        buttonList.add(new GuiButton(BTN_PREV, l, y, 56, 20, "< Prev"));
        buttonList.add(new GuiButton(BTN_DONE, l + 62, y, 66, 20, "Done"));
        buttonList.add(new GuiButton(BTN_NEXT, l + 134, y, 56, 20, "Next >"));
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        int count = RecipeBookData.all().size();
        if (button.id == BTN_DONE) {
            mc.displayGuiScreen(parent);
        } else if (count > 0 && button.id == BTN_PREV) {
            page = (page + count - 1) % count;
        } else if (count > 0 && button.id == BTN_NEXT) {
            page = (page + 1) % count;
        }
        lastPage = page;
    }

    @Override
    protected void keyTyped(char typed, int key) {
        if (key == 1) {                    // Escape: go back to where we came from
            mc.displayGuiScreen(parent);
        } else {
            super.keyTyped(typed, key);
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private void slotBox(int x, int y, int size) {
        drawRect(x, y, x + size, y + size, 0xFF373737);
        drawRect(x + 1, y + 1, x + size - 1, y + size - 1, 0xFF8B8B8B);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        int l = (width - PANEL_W) / 2;
        int t = (height - PANEL_H) / 2;

        drawRect(l - 3, t - 3, l + PANEL_W + 3, t + PANEL_H + 3, 0xFF000000);   // border
        drawRect(l, t, l + PANEL_W, t + PANEL_H, 0xFFC6C6C6);                    // panel

        List<RecipeBookData.Entry> all = RecipeBookData.all();
        ItemStack[] stacks = new ItemStack[10];     // 9 grid cells + the result
        int[] sx = new int[10];
        int[] sy = new int[10];

        if (all.isEmpty()) {
            fontRendererObj.drawString("No recipes found.", l + 8, t + 8, 0x404040);
        } else {
            int index = page % all.size();
            RecipeBookData.Entry e = all.get(index);

            String title = e.output.getDisplayName();
            fontRendererObj.drawString(title, l + (PANEL_W - fontRendererObj.getStringWidth(title)) / 2, t + 7, 0x404040);

            int gx = l + 18;
            int gy = t + 22;
            for (int i = 0; i < 9; i++) {
                int cx = gx + (i % 3) * 18;
                int cy = gy + (i / 3) * 18;
                slotBox(cx, cy, 18);
                stacks[i] = e.grid[i];
                sx[i] = cx + 1;
                sy[i] = cy + 1;
            }

            fontRendererObj.drawString("->", l + 82, t + 45, 0x404040);
            int ox = l + 106;
            int oy = t + 36;
            slotBox(ox, oy, 26);
            stacks[9] = e.output;
            sx[9] = ox + 5;
            sy[9] = oy + 5;

            for (int i = 0; i < e.lines.length; i++) {
                fontRendererObj.drawString(e.lines[i], l + 10, t + 84 + i * 12, 0x404040);
            }
            String number = (index + 1) + " / " + all.size();
            fontRendererObj.drawString(number, l + PANEL_W - 8 - fontRendererObj.getStringWidth(number),
                    t + PANEL_H - 12, 0x606060);
        }

        // the items, drawn with the normal inventory lighting
        ItemStack hovered = null;
        RenderHelper.enableGUIStandardItemLighting();
        GL11.glEnable(GL12.GL_RESCALE_NORMAL);
        ITEM_RENDER.zLevel = 100.0F;
        for (int i = 0; i < stacks.length; i++) {
            if (stacks[i] != null) {
                ITEM_RENDER.renderItemAndEffectIntoGUI(fontRendererObj, mc.getTextureManager(), stacks[i], sx[i], sy[i]);
                if (mouseX >= sx[i] && mouseX < sx[i] + 16 && mouseY >= sy[i] && mouseY < sy[i] + 16) {
                    hovered = stacks[i];
                }
            }
        }
        ITEM_RENDER.zLevel = 0.0F;
        GL11.glDisable(GL12.GL_RESCALE_NORMAL);
        RenderHelper.disableStandardItemLighting();

        super.drawScreen(mouseX, mouseY, partialTicks);      // the buttons

        if (hovered != null) {
            renderToolTip(hovered, mouseX, mouseY);
        }
    }
}
