package com.example.orefarm;

import java.util.List;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.world.World;

/**
 * Right-click an Ore Farm with this to upgrade it one level (cores are taken from your whole inventory).
 * Sneak + right-click upgrades as many levels as you can afford.
 * Upgrades 1-10 cost 1 core each, 11-20 cost 2, 21-30 cost 4, and so on (doubling every 10 upgrades).
 */
public class ItemFarmCore extends Item {

    /** Most levels one sneak-click can buy (keeps a single click quick). */
    private static final int MAX_BULK_UPGRADES = 1000;

    public ItemFarmCore() {
        setUnlocalizedName("farmCore");                       // lang key: item.farmCore.name
        setTextureName(OreFarmMod.MODID + ":farm_core");      // textures/items/farm_core.png
        setCreativeTab(CreativeTabs.tabMisc);
    }

    @Override
    @SideOnly(Side.CLIENT)
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean advanced) {
        list.add(EnumChatFormatting.GRAY + "Right-click an Ore Farm to upgrade it one level");
        list.add(EnumChatFormatting.GRAY + "Sneak + right-click: upgrade as far as you can afford");
        list.add(EnumChatFormatting.DARK_GRAY + "Upgrades 1-10 cost 1 core, 11-20 cost 2, 21-30 cost 4 ...");
    }

    /** Sneak + right-click on a farm: buy as many upgrades as the cores in your inventory allow. */
    @Override
    public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int x, int y, int z,
                             int side, float hitX, float hitY, float hitZ) {
        Block block = world.getBlock(x, y, z);
        if (!(block instanceof BlockOreFarm)) return false;
        if (world.isRemote) return true;                       // the server does the real work

        TileEntity te = world.getTileEntity(x, y, z);
        if (!(te instanceof TileOreFarm)) return true;
        TileOreFarm farm = (TileOreFarm) te;

        boolean creative = player.capabilities.isCreativeMode;
        int bought = 0;
        long spent = 0L;
        while (bought < MAX_BULK_UPGRADES) {
            long cost = TileOreFarm.upgradeCost(farm.getLevel() + 1);
            if (creative) {
                if (bought >= 10) break;                       // creative: 10 free levels per click
            } else {
                if (cost > countCores(player)) break;
                takeCores(player, cost);
                spent += cost;
            }
            if (!farm.upgrade()) break;
            bought++;
        }

        if (bought == 0) {
            long cost = TileOreFarm.upgradeCost(farm.getLevel() + 1);
            tell(player, EnumChatFormatting.RED + "Not enough Farm Cores: upgrade " + (farm.getLevel() + 1)
                    + " needs " + cost + " (you have " + countCores(player) + ").");
        } else {
            world.playSoundEffect(x + 0.5D, y + 0.5D, z + 0.5D, "random.levelup", 0.6F, 1.0F);
            tell(player, EnumChatFormatting.GREEN + "Upgraded " + bought + " level" + (bought == 1 ? "" : "s")
                    + " to level " + farm.getLevel() + (creative ? "." : " (used " + spent + " Farm Cores)."));
        }
        tell(player, farm.statusLine());
        return true;
    }

    /** How many Farm Cores the player carries in total. */
    public static long countCores(EntityPlayer player) {
        long total = 0L;
        for (ItemStack s : player.inventory.mainInventory) {
            if (s != null && s.getItem() == OreFarmMod.farmCore) total += s.stackSize;
        }
        return total;
    }

    /** Takes that many Farm Cores out of the player's inventory (call countCores first). */
    public static void takeCores(EntityPlayer player, long amount) {
        ItemStack[] inv = player.inventory.mainInventory;
        for (int i = 0; i < inv.length && amount > 0L; i++) {
            ItemStack s = inv[i];
            if (s != null && s.getItem() == OreFarmMod.farmCore) {
                int take = (int) Math.min((long) s.stackSize, amount);
                s.stackSize -= take;
                amount -= take;
                if (s.stackSize <= 0) inv[i] = null;
            }
        }
        player.inventory.markDirty();
        player.inventoryContainer.detectAndSendChanges();
    }

    private static void tell(EntityPlayer player, String message) {
        player.addChatMessage(new ChatComponentText(message));
    }
}
