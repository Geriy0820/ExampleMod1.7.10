package com.example.orefarm;

import java.util.Locale;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

@Mod(modid = OreFarmMod.MODID, name = "Ore Farm", version = "4.0")
public class OreFarmMod {
    public static final String MODID = "orefarm";

    @SidedProxy(clientSide = "com.example.orefarm.ClientProxy", serverSide = "com.example.orefarm.CommonProxy")
    public static CommonProxy proxy;

    public static Item farmCore;
    public static Item minerPickaxe;
    public static Item recipeBook;
    public static Block[] farms;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {

        ItemStack iron = new ItemStack(Items.iron_ingot);
        ItemStack redstone = new ItemStack(Items.redstone);
        ItemStack glass = new ItemStack(Blocks.glass);

        // ---------- Farm Core: upgrades a farm (the cost doubles every 10 upgrades) ----------
        farmCore = new ItemFarmCore();
        GameRegistry.registerItem(farmCore, "farm_core");
        GameRegistry.addRecipe(new ItemStack(farmCore),
                "IRI",
                "RGR",
                "IRI",
                'I', Items.iron_ingot,
                'R', Items.redstone,
                'G', Blocks.glass);
        RecipeBookData.add(new RecipeBookData.Entry(new ItemStack(farmCore),
                new ItemStack[] { iron, redstone, iron, redstone, glass, redstone, iron, redstone, iron },
                "Iron ingots: the 4 corners", "Glass: the middle", "Redstone: the 4 sides"));

        // ---------- One single-block farm per ore ----------
        String[] names = { "Coal", "Iron", "Gold", "Redstone", "Lapis", "Diamond", "Emerald" };

        Block[] ores = {
            Blocks.coal_ore, Blocks.iron_ore, Blocks.gold_ore, Blocks.redstone_ore,
            Blocks.lapis_ore, Blocks.diamond_ore, Blocks.emerald_ore
        };

        // The storage block of each ore: 3 of them go on the bottom row of that farm's recipe
        Block[] storage = {
            Blocks.coal_block, Blocks.iron_block, Blocks.gold_block, Blocks.redstone_block,
            Blocks.lapis_block, Blocks.diamond_block, Blocks.emerald_block
        };

        // Ticks per mining at level 0 (20 ticks = 1 second). Edit these to rebalance.
        int[] baseTicks = { 100, 140, 200, 160, 160, 400, 600 };

        farms = new Block[names.length];
        for (int i = 0; i < names.length; i++) {
            String lower = names[i].toLowerCase(Locale.ENGLISH);

            BlockOreFarm farm = new BlockOreFarm(names[i], lower + "_farm", ores[i], baseTicks[i]);
            farm.setBlockName(lower + "Farm");           // lang key: tile.<lower>Farm.name
            farm.setCreativeTab(CreativeTabs.tabBlock);
            GameRegistry.registerBlock(farm, ItemBlockOreFarm.class, lower + "_farm");
            farms[i] = farm;

            // Farm Core in the middle, 3 storage blocks of the ore on the bottom row, glass everywhere else
            GameRegistry.addRecipe(new ItemStack(farm),
                    "GGG",
                    "GCG",
                    "BBB",
                    'G', Blocks.glass,
                    'C', farmCore,
                    'B', storage[i]);
            ItemStack core = new ItemStack(farmCore);
            ItemStack block = new ItemStack(storage[i]);
            RecipeBookData.add(new RecipeBookData.Entry(new ItemStack(farm),
                    new ItemStack[] { glass, glass, glass, glass, core, glass, block, block, block },
                    "Farm Core: the middle", "3 " + names[i] + " Blocks: bottom row", "Glass: all other slots"));
        }

        GameRegistry.registerTileEntity(TileOreFarm.class, MODID + ":ore_farm");

        // ---------- Miner's Pickaxe: Fortune V, Efficiency X, unbreakable, mines 3x3 ----------
        minerPickaxe = new ItemMinerPickaxe();
        GameRegistry.registerItem(minerPickaxe, "miner_pickaxe");

        // ---------- Recipe book: shows the Ore Farm recipes ----------
        recipeBook = new ItemRecipeBook();
        GameRegistry.registerItem(recipeBook, "recipe_book");
        GameRegistry.addShapelessRecipe(new ItemStack(recipeBook), Items.book, Items.redstone);

        // Every player is handed a pickaxe and a recipe book the first time they join a world.
        FMLCommonHandler.instance().bus().register(new StarterGearHandler());

        proxy.init();
    }
}
