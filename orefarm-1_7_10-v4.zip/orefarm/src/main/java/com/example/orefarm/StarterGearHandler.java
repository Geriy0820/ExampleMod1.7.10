package com.example.orefarm;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

/** Gives every player the Miner's Pickaxe and the Recipe Book once: the first time they join a world. */
public class StarterGearHandler {

    /** Forge keeps everything under this tag on the player, even through death. */
    private static final String PERSISTED_TAG = "PlayerPersisted";
    private static final String PICKAXE_KEY = "orefarm_miner_pickaxe";
    private static final String BOOK_KEY = "orefarm_recipe_book";

    @SubscribeEvent
    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        EntityPlayer player = event.player;
        if (player == null || player.worldObj.isRemote) return;

        NBTTagCompound persisted = player.getEntityData().getCompoundTag(PERSISTED_TAG);
        boolean changed = false;

        if (!persisted.getBoolean(PICKAXE_KEY)) {
            persisted.setBoolean(PICKAXE_KEY, true);
            give(player, ItemMinerPickaxe.createStarterPick());
            tell(player, "You received a Miner's Pickaxe: Fortune V, Efficiency X, unbreakable, mines 3x3.");
            changed = true;
        }
        if (!persisted.getBoolean(BOOK_KEY)) {
            persisted.setBoolean(BOOK_KEY, true);
            give(player, new ItemStack(OreFarmMod.recipeBook));
            tell(player, "You received an Ore Farm Recipe Book (right-click it to see the recipes).");
            changed = true;
        }

        if (changed) {
            player.getEntityData().setTag(PERSISTED_TAG, persisted);   // attach it in case it was just created
        }
    }

    private static void give(EntityPlayer player, ItemStack stack) {
        if (!player.inventory.addItemStackToInventory(stack)) {
            player.dropPlayerItemWithRandomChoice(stack, false);       // inventory full: drop it at their feet
        }
    }

    private static void tell(EntityPlayer player, String message) {
        player.addChatMessage(new ChatComponentText(EnumChatFormatting.GOLD + message));
    }
}
