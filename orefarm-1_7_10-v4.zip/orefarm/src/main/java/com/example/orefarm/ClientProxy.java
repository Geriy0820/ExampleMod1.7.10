package com.example.orefarm;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;

@SideOnly(Side.CLIENT)
public class ClientProxy extends CommonProxy {

    @Override
    public void init() {
        MinecraftForge.EVENT_BUS.register(new ClientEvents());
    }

    @Override
    public void openRecipeBook() {
        Minecraft.getMinecraft().displayGuiScreen(new GuiRecipeBook(null));
    }
}
