ORE FARM v4 (Minecraft 1.7.10 Forge)

WHAT'S NEW IN v4
1. NO LIMIT on upgrades. Every upgrade adds +1 speed and +1 Fortune; every 10 upgrades they double.
2. The Farm Core cost doubles every 10 upgrades (1, 2, 4, 8 ...).
   Sneak + right-click a farm while holding Farm Cores = upgrade as many levels as you can afford.
3. New recipes (see RECIPES).
4. Recipe book: an item (right-click it) AND a "Recipes" button on the crafting table screen.
5. Everything from v3 stays: Iron and Gold farms give ingots, the Miner's Pickaxe, 64x64 textures.

UPGRADES
Level = number of upgrades. Level 0 = a freshly crafted farm.
   Speed   = level + 1 below level 10, then (level x 2^(level / 10))
   Fortune = level, then (level x 2^(level / 10))     (whole-number division)
   Farm Cores for upgrade N = 2^((N - 1) / 10)        (1 for upgrades 1-10, 2 for 11-20, 4 for 21-30 ...)

 LEVEL   SPEED    FORTUNE   CORES FOR THE NEXT UPGRADE
   0     1x       0         1
   5     6x       5         1
   9     10x      9         1
  10     20x      20        2
  11     22x      22        2
  20     80x      80        4
  30     240x     240       8
  31     248x     248       8
  50     1.6Kx    1.6K      32
 100     102Kx    102K      1024

Fortune works like vanilla Fortune on average, for every ore (iron and gold ingots too).
A farm holds 2048 items plus 2048 more per level. A full farm waits until you take items out.
Breaking a farm spills at most 128 stacks of what it stores; take items out first (right-click, empty hand).
STACK SIZES: use the InfiniStack mod (already in your mods folder). This mod doesn't change stack sizes.

FARMS (one block each): Coal, Iron, Gold, Redstone, Lapis, Diamond, Emerald
- Make the ore's drops on a timer. Iron/Gold come out as ingots.
- Push items into any touching chest / double chest / hopper / furnace.
- Empty-hand right-click = take items. Sneak + empty hand = info only.
- Breaking a farm gives the farm back with its level.
- Base time at level 0: Coal 5s, Iron 7s, Gold 10s, Redstone 8s, Lapis 8s, Diamond 20s, Emerald 30s.

FARM CORE: right-click a farm with Farm Cores in your inventory (cores come from your whole inventory).
           Sneak + right-click = upgrade as many levels as you can afford.

RECIPES
Farm Core:   I R I / R G R / I R I     (I iron ingot, R redstone, G glass)
Any farm:    G G G / G C G / B B B     (G glass, C Farm Core, B = 3 storage blocks of that ore:
                                        coal / iron / gold / redstone / lapis / diamond / emerald block)
Recipe book: book + redstone (shapeless). You also get one the first time you join a world.

MINER'S PICKAXE: given the first time you join a world. Diamond tier, Fortune V, Efficiency X, never breaks,
mines 3x3 (sneak = one block).

TESTING / COMMANDS
/give @p orefarm:coal_farm 1 0 {Level:100}     a level 100 farm (also: iron_farm, gold_farm, redstone_farm,
                                               lapis_farm, diamond_farm, emerald_farm)
/give @p orefarm:farm_core 64                  Farm Cores
/give @p orefarm:recipe_book                   recipe book
/give @p orefarm:miner_pickaxe 1 0 {ench:[{id:35,lvl:5},{id:32,lvl:10}]}    spare pickaxe

BUILDING THE JAR (GitHub, from a tablet)
Upload this zip to the root of your GitHub fork and upload build-orefarm-v2.yml into .github/workflows.
Then Actions -> Build OreFarm (v2) -> Run workflow. The newest zip you uploaded is the one that gets built.

TWEAK
OreFarmMod.java       -> baseTicks (time per mining at level 0), recipes.
TileOreFarm.java      -> DOUBLE_EVERY (10), BASE_CAPACITY, AUTO_SMELT, FORTUNE_BOOSTS_INGOTS.
ItemMinerPickaxe.java -> FORTUNE_LEVEL, EFFICIENCY_LEVEL.
