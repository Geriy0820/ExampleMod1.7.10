package com.example.orefarm;

import java.util.List;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumChatFormatting;

/**
 * Item form of a farm. The upgrade level is stored in the stack's NBT ("Level"), so upgrades survive being
 * picked up. The damage value is only the texture (0-4). A stack with no NBT uses its damage value as the
 * level, so old v2 farms (damage 0-4) and "/give @p orefarm:coal_farm 1 25" both work.
 */
public class ItemBlockOreFarm extends ItemBlock {
    private final BlockOreFarm farm;

    public ItemBlockOreFarm(Block block) {
        super(block);
        this.farm = (BlockOreFarm) block;
        setHasSubtypes(true);
        setMaxDamage(0);
    }

    /** Block metadata can only be 0-15, and we only use it for the texture. */
    @Override
    public int getMetadata(int damage) {
        return TileOreFarm.clampStage(damage);
    }

    /** The upgrade level a farm item stands for. */
    public static int levelOf(ItemStack stack) {
        if (stack.hasTagCompound() && stack.getTagCompound().hasKey("Level")) {
            return TileOreFarm.clampLevel(stack.getTagCompound().getInteger("Level"));
        }
        return TileOreFarm.clampLevel(stack.getItemDamage());
    }

    /** Builds a farm item of the given level. */
    public static ItemStack stackFor(BlockOreFarm farm, int level) {
        level = TileOreFarm.clampLevel(level);
        ItemStack stack = new ItemStack(farm, 1, TileOreFarm.stageFor(level));
        if (level > 0) {
            NBTTagCompound tag = new NBTTagCompound();
            tag.setInteger("Level", level);
            stack.setTagCompound(tag);
        }
        return stack;
    }

    @Override
    @SideOnly(Side.CLIENT)
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean advanced) {
        int level = levelOf(stack);
        float seconds = TileOreFarm.secondsPerOre(farm.getBaseTicks(), level);

        list.add(EnumChatFormatting.GRAY + "Upgrade " + level + "/" + TileOreFarm.MAX_LEVEL);
        list.add(EnumChatFormatting.GRAY + "1 ore every " + String.format("%.2f", seconds)
                + "s, Fortune " + TileOreFarm.fortuneFor(level));
        if (level < TileOreFarm.MAX_LEVEL) {
            list.add(EnumChatFormatting.DARK_GRAY + "Right-click with a Farm Core to upgrade");
        }
    }
}
