package com.example.orefarm;

import java.util.List;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeHooks;

/**
 * Diamond-tier pickaxe that never breaks and mines a 3x3 square (the face you are looking at).
 * Hold sneak to mine a single block. Every player is given one with Fortune V + Efficiency X
 * the first time they join a world (see StarterGearHandler).
 */
public class ItemMinerPickaxe extends ItemPickaxe {

    public static final int FORTUNE_LEVEL = 5;
    public static final int EFFICIENCY_LEVEL = 10;

    /** True while the 8 extra blocks are being broken, so they don't each trigger another 3x3. */
    private static boolean breaking = false;

    public ItemMinerPickaxe() {
        super(Item.ToolMaterial.EMERALD);                  // EMERALD is the diamond tier in 1.7.10
        setUnlocalizedName("minerPickaxe");                // lang key: item.minerPickaxe.name
        setTextureName("diamond_pickaxe");                 // reuse the vanilla diamond pickaxe picture
        setCreativeTab(CreativeTabs.tabTools);
        setMaxDamage(0);                                   // no durability = never breaks
    }

    /** The enchanted pickaxe handed out at the start of a world. */
    public static ItemStack createStarterPick() {
        ItemStack pick = new ItemStack(OreFarmMod.minerPickaxe);
        pick.addEnchantment(Enchantment.fortune, FORTUNE_LEVEL);
        pick.addEnchantment(Enchantment.efficiency, EFFICIENCY_LEVEL);
        pick.getTagCompound().setBoolean("Unbreakable", true);   // belt and braces: also flagged unbreakable
        return pick;
    }

    /** Creative menu shows the enchanted version. */
    @Override
    @SideOnly(Side.CLIENT)
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void getSubItems(Item item, CreativeTabs tab, List list) {
        list.add(createStarterPick());
    }

    @Override
    @SideOnly(Side.CLIENT)
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean advanced) {
        list.add(EnumChatFormatting.GRAY + "Never breaks. Mines a 3x3 area.");
        list.add(EnumChatFormatting.DARK_GRAY + "Sneak to mine a single block");
    }

    /**
     * Called (server side too) just before the targeted block breaks. We break the 8 blocks around it
     * in the same flat square, then return false so the targeted block breaks the normal way.
     */
    @Override
    public boolean onBlockStartBreak(ItemStack stack, int x, int y, int z, EntityPlayer player) {
        World world = player.worldObj;
        if (world.isRemote || breaking || player.isSneaking() || !(player instanceof EntityPlayerMP)) {
            return false;
        }

        // Which face of the block are we mining? That decides which way the 3x3 square faces.
        MovingObjectPosition hit = getMovingObjectPositionFromPlayer(world, player, false);
        if (hit == null || hit.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) return false;
        if (hit.blockX != x || hit.blockY != y || hit.blockZ != z) return false;
        int side = hit.sideHit;

        EntityPlayerMP serverPlayer = (EntityPlayerMP) player;
        breaking = true;
        try {
            for (int a = -1; a <= 1; a++) {
                for (int b = -1; b <= 1; b++) {
                    if (a == 0 && b == 0) continue;

                    int nx = x;
                    int ny = y;
                    int nz = z;
                    if (side == 0 || side == 1) {          // bottom/top face: flat square
                        nx += a;
                        nz += b;
                    } else if (side == 2 || side == 3) {   // north/south face
                        nx += a;
                        ny += b;
                    } else {                               // west/east face
                        nz += a;
                        ny += b;
                    }

                    if (canMineToo(stack, world, player, nx, ny, nz)) {
                        serverPlayer.theItemInWorldManager.tryHarvestBlock(nx, ny, nz);
                    }
                }
            }
        } finally {
            breaking = false;
        }
        return false;
    }

    /** Only stone-type blocks this pickaxe can really harvest get taken along (never dirt, wood, bedrock...). */
    private static boolean canMineToo(ItemStack stack, World world, EntityPlayer player, int x, int y, int z) {
        if (!world.blockExists(x, y, z)) return false;

        Block block = world.getBlock(x, y, z);
        if (block == null) return false;
        Material material = block.getMaterial();
        if (material == Material.air || material.isLiquid()) return false;
        if (block.getBlockHardness(world, x, y, z) < 0.0F) return false;     // bedrock and other unbreakables

        int meta = world.getBlockMetadata(x, y, z);
        boolean stoneType = ForgeHooks.isToolEffective(stack, block, meta)
                || material == Material.rock || material == Material.iron || material == Material.anvil;
        return stoneType && block.canHarvestBlock(player, meta);
    }
}
