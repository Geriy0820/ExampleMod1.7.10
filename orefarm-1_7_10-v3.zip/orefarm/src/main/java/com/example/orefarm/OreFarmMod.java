package com.example.orefarm;

import java.util.Locale;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

@Mod(modid = OreFarmMod.MODID, name = "Ore Farm", version = "3.0")
public class OreFarmMod {
    public static final String MODID = "orefarm";

    public static Item farmCore;
    public static Item minerPickaxe;
    public static Block[] farms;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {

        // ---------- Farm Core: right-click a farm with it to upgrade one level (25 levels) ----------
        farmCore = new ItemFarmCore();
        GameRegistry.registerItem(farmCore, "farm_core");
        GameRegistry.addRecipe(new ItemStack(farmCore),
                "GRG",
                "RDR",
                "GRG",
                'G', Items.gold_ingot,
                'R', Items.redstone,
                'D', Items.diamond);

        // ---------- One single-block farm per ore ----------
        String[] names = { "Coal", "Iron", "Gold", "Redstone", "Lapis", "Diamond", "Emerald" };

        Block[] ores = {
            Blocks.coal_ore, Blocks.iron_ore, Blocks.gold_ore, Blocks.redstone_ore,
            Blocks.lapis_ore, Blocks.diamond_ore, Blocks.emerald_ore
        };

        // Ticks per ore at level 0 (20 ticks = 1 second). Edit these to rebalance.
        int[] baseTicks = { 100, 140, 200, 160, 160, 400, 600 };

        // The material used in each farm's crafting recipe
        ItemStack[] mats = {
            new ItemStack(Items.coal),
            new ItemStack(Items.iron_ingot),
            new ItemStack(Items.gold_ingot),
            new ItemStack(Items.redstone),
            new ItemStack(Items.dye, 1, 4),   // lapis lazuli
            new ItemStack(Items.diamond),
            new ItemStack(Items.emerald)
        };

        farms = new Block[names.length];
        for (int i = 0; i < names.length; i++) {
            String lower = names[i].toLowerCase(Locale.ENGLISH);

            BlockOreFarm farm = new BlockOreFarm(names[i], lower + "_farm", ores[i], baseTicks[i]);
            farm.setBlockName(lower + "Farm");           // lang key: tile.<lower>Farm.name
            farm.setCreativeTab(CreativeTabs.tabBlock);
            GameRegistry.registerBlock(farm, ItemBlockOreFarm.class, lower + "_farm");
            farms[i] = farm;

            GameRegistry.addRecipe(new ItemStack(farm),
                    "IHI",
                    "MRM",
                    "IMI",
                    'I', Items.iron_ingot,
                    'H', Blocks.hopper,
                    'R', Items.redstone,
                    'M', mats[i]);
        }

        GameRegistry.registerTileEntity(TileOreFarm.class, MODID + ":ore_farm");

        // ---------- Miner's Pickaxe: Fortune V, Efficiency X, unbreakable, mines 3x3 ----------
        minerPickaxe = new ItemMinerPickaxe();
        GameRegistry.registerItem(minerPickaxe, "miner_pickaxe");

        // Every player is handed one the first time they join a world.
        FMLCommonHandler.instance().bus().register(new StarterGearHandler());
    }
}
