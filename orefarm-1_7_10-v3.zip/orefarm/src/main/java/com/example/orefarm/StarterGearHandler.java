package com.example.orefarm;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

/** Gives every player the Miner's Pickaxe once: the first time they join a world. */
public class StarterGearHandler {

    /** Forge keeps everything under this tag on the player, even through death. */
    private static final String PERSISTED_TAG = "PlayerPersisted";
    private static final String GIVEN_KEY = "orefarm_miner_pickaxe";

    @SubscribeEvent
    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        EntityPlayer player = event.player;
        if (player == null || player.worldObj.isRemote) return;

        NBTTagCompound persisted = player.getEntityData().getCompoundTag(PERSISTED_TAG);
        if (persisted.getBoolean(GIVEN_KEY)) return;

        persisted.setBoolean(GIVEN_KEY, true);
        player.getEntityData().setTag(PERSISTED_TAG, persisted);   // attach it in case it was just created

        ItemStack pick = ItemMinerPickaxe.createStarterPick();
        if (!player.inventory.addItemStackToInventory(pick)) {
            player.dropPlayerItemWithRandomChoice(pick, false);    // inventory full: drop it at their feet
        }
        player.addChatMessage(new ChatComponentText(EnumChatFormatting.GOLD
                + "You received a Miner's Pickaxe: Fortune V, Efficiency X, unbreakable, mines 3x3."));
    }
}
