package com.example.orefarm;

import java.util.ArrayList;
import java.util.List;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;

/**
 * One block = one complete auto farm for a single ore.
 * The upgrade level (0-25) lives in the tile entity. The block metadata (0-4) is only the texture to draw.
 * Each farm makes its ore's drops on a timer, pushes them into any touching chest/hopper/furnace,
 * and stores the rest inside.
 */
public class BlockOreFarm extends BlockContainer {
    private final String displayName;
    private final String iconBase;
    private final Block ore;
    private final int baseTicks;

    @SideOnly(Side.CLIENT)
    private IIcon[] icons;

    public BlockOreFarm(String displayName, String iconBase, Block ore, int baseTicks) {
        super(Material.rock);
        this.displayName = displayName;
        this.iconBase = iconBase;
        this.ore = ore;
        this.baseTicks = baseTicks;
        setHardness(3.5F);
        setResistance(10.0F);
        setStepSound(soundTypePiston);
        setHarvestLevel("pickaxe", 0);
    }

    public Block getOre() {
        return ore;
    }

    public int getBaseTicks() {
        return baseTicks;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public TileEntity createNewTileEntity(World world, int meta) {
        return new TileOreFarm();
    }

    @Override
    public int damageDropped(int meta) {
        return meta;
    }

    /** No normal drop: breakBlock() hands out the farm item itself so it can keep its upgrade level. */
    @Override
    public ArrayList<ItemStack> getDrops(World world, int x, int y, int z, int metadata, int fortune) {
        return new ArrayList<ItemStack>();
    }

    /** Placing a farm item restores the upgrade level it had. */
    @Override
    public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase placer, ItemStack stack) {
        TileEntity te = world.getTileEntity(x, y, z);
        if (te instanceof TileOreFarm && stack != null) {
            ((TileOreFarm) te).setLevel(ItemBlockOreFarm.levelOf(stack));
        }
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void registerBlockIcons(IIconRegister reg) {
        icons = new IIcon[TileOreFarm.STAGES];
        for (int i = 0; i < icons.length; i++) {
            icons[i] = reg.registerIcon(OreFarmMod.MODID + ":" + iconBase + "_t" + (i + 1));
        }
    }

    @Override
    @SideOnly(Side.CLIENT)
    public IIcon getIcon(int side, int meta) {
        return icons[TileOreFarm.clampStage(meta)];
    }

    /** Creative menu: a fresh farm and a fully upgraded (level 25) one. */
    @Override
    @SideOnly(Side.CLIENT)
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void getSubBlocks(Item item, CreativeTabs tab, List list) {
        list.add(ItemBlockOreFarm.stackFor(this, 0));
        list.add(ItemBlockOreFarm.stackFor(this, TileOreFarm.MAX_LEVEL));
    }

    @Override
    public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player,
                                    int side, float hitX, float hitY, float hitZ) {
        ItemStack held = player.getHeldItem();
        boolean holdingCore = held != null && held.getItem() == OreFarmMod.farmCore;

        // Holding anything else (a chest, hopper, tool...)? Let normal placing/using happen.
        if (held != null && !holdingCore) return false;
        if (world.isRemote) return true;

        TileEntity te = world.getTileEntity(x, y, z);
        if (!(te instanceof TileOreFarm)) return true;
        TileOreFarm farm = (TileOreFarm) te;

        if (holdingCore) {
            if (!farm.upgrade()) {
                tell(player, EnumChatFormatting.RED + "This farm is already at max level!");
                return true;
            }
            if (!player.capabilities.isCreativeMode) {
                player.inventory.decrStackSize(player.inventory.currentItem, 1);
            }
            world.playSoundEffect(x + 0.5D, y + 0.5D, z + 0.5D, "random.levelup", 0.6F, 1.0F);
            tell(player, EnumChatFormatting.GREEN + "Upgraded!");
        } else if (!player.isSneaking()) {
            // Empty hand: take what's stored inside. (Sneak + empty hand = just show info.)
            int got = farm.giveTo(player);
            if (got > 0) {
                tell(player, EnumChatFormatting.YELLOW + "Collected " + got + ".");
            }
        }

        tell(player, farm.statusLine());
        return true;
    }

    /** Drop whatever is stored inside, plus the farm itself (with its upgrade level), when the farm is broken. */
    @Override
    public void breakBlock(World world, int x, int y, int z, Block block, int meta) {
        if (!world.isRemote) {
            TileEntity te = world.getTileEntity(x, y, z);
            if (te instanceof TileOreFarm) {
                TileOreFarm farm = (TileOreFarm) te;
                farm.dropBuffer();
                dropBlockAsItem(world, x, y, z, ItemBlockOreFarm.stackFor(this, farm.getLevel()));
            }
        }
        super.breakBlock(world, x, y, z, block, meta);
    }

    private static void tell(EntityPlayer player, String message) {
        player.addChatMessage(new ChatComponentText(message));
    }
}
