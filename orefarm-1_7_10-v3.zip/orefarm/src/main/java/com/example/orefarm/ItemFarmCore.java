package com.example.orefarm;

import java.util.List;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumChatFormatting;

/** Right-click an Ore Farm block with this to upgrade it by one level (25 levels in total). */
public class ItemFarmCore extends Item {

    public ItemFarmCore() {
        setUnlocalizedName("farmCore");                       // lang key: item.farmCore.name
        setTextureName(OreFarmMod.MODID + ":farm_core");      // textures/items/farm_core.png
        setCreativeTab(CreativeTabs.tabMisc);
    }

    @Override
    @SideOnly(Side.CLIENT)
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean advanced) {
        list.add(EnumChatFormatting.GRAY + "Right-click an Ore Farm to upgrade it one level (max 25)");
    }
}
