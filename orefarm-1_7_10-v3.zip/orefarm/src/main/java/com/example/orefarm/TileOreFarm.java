package com.example.orefarm;

import net.minecraft.block.Block;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.inventory.InventoryLargeChest;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.EnumChatFormatting;
import net.minecraftforge.common.util.ForgeDirection;

import java.util.ArrayList;

public class TileOreFarm extends TileEntity {

    /** How many Farm Core upgrades a farm can take. Level 0 = freshly crafted, level 25 = maxed out. */
    public static final int MAX_LEVEL = 25;

    /** Block textures per farm (t1..t5). The 26 levels are spread over these. */
    public static final int STAGES = 5;

    /** Iron and gold ore drop themselves; with this on, the farm hands out ingots instead (no furnace needed). */
    private static final boolean AUTO_SMELT = true;

    /** Let Fortune multiply those ingots too (vanilla Fortune does nothing for iron/gold ore). */
    private static final boolean FORTUNE_BOOSTS_INGOTS = true;

    /** Most items a farm will hold inside itself. */
    private static final int MAX_BUFFER = 2048;

    /** Speed multiplier for levels 0-25. */
    private static final float[] SPEED = new float[MAX_LEVEL + 1];

    /** Fortune level for levels 0-25 (more drops from each "mining"). */
    private static final int[] FORTUNE = new int[MAX_LEVEL + 1];

    static {
        // Levels 0-4 are the same as the old 5 tiers. After that: +1.5x speed every level, +1 Fortune every 3 levels.
        float[] firstSpeeds = { 1.0F, 1.5F, 2.5F, 4.0F, 6.0F };
        int[] firstFortunes = { 0, 0, 1, 2, 3 };
        for (int i = 0; i <= MAX_LEVEL; i++) {
            if (i < firstSpeeds.length) {
                SPEED[i] = firstSpeeds[i];
                FORTUNE[i] = firstFortunes[i];
            } else {
                SPEED[i] = 6.0F + (i - 4) * 1.5F;
                FORTUNE[i] = 3 + (i - 4) / 3;
            }
        }
    }

    private int level = -1;       // upgrade level 0-25; -1 = saved by the old version (fixed up in updateEntity)
    private float progress;       // mining progress; one ore is made each time it passes the ore's base time
    private ItemStack bufferType; // what is stored (size 1, just the type)
    private int bufferCount;      // how many are stored

    // ------------------------------------------------------------------ helpers

    public static int clampLevel(int level) {
        return Math.max(0, Math.min(MAX_LEVEL, level));
    }

    public static int clampStage(int stage) {
        return Math.max(0, Math.min(STAGES - 1, stage));
    }

    /** Which texture (0-4) a farm of this level uses: level 0 = t1, 1-6 = t2, 7-12 = t3, 13-18 = t4, 19-25 = t5. */
    public static int stageFor(int level) {
        level = clampLevel(level);
        return level == 0 ? 0 : clampStage(1 + (level - 1) / 6);
    }

    public static float speedFor(int level) {
        return SPEED[clampLevel(level)];
    }

    public static int fortuneFor(int level) {
        return FORTUNE[clampLevel(level)];
    }

    /** Seconds between two "minings" for an ore with this base time (ticks) at this level. */
    public static float secondsPerOre(int baseTicks, int level) {
        return baseTicks / speedFor(level) / 20.0F;
    }

    // -------------------------------------------------------------------- level

    /** Current upgrade level (also right for an old farm that hasn't ticked yet: its tier is in the metadata). */
    public int getLevel() {
        if (level >= 0) return level;
        if (worldObj != null) return clampLevel(worldObj.getBlockMetadata(xCoord, yCoord, zCoord));
        return 0;
    }

    /** Used when a farm is placed from an item, so it keeps the level it had. */
    public void setLevel(int newLevel) {
        level = clampLevel(newLevel);
        progress = 0.0F;
        showStage();
        markDirty();
    }

    /** Uses up one Farm Core. Returns false if the farm is already at the top level. */
    public boolean upgrade() {
        int current = getLevel();
        if (current >= MAX_LEVEL) return false;
        level = current + 1;
        showStage();
        markDirty();
        return true;
    }

    /** Keeps the block's metadata (= which texture is drawn) in step with the level. Block metadata only holds 0-15. */
    private void showStage() {
        if (worldObj == null || worldObj.isRemote) return;
        int stage = stageFor(level);
        if (worldObj.getBlockMetadata(xCoord, yCoord, zCoord) != stage) {
            worldObj.setBlockMetadataWithNotify(xCoord, yCoord, zCoord, stage, 3);
        }
    }

    // --------------------------------------------------------------------- tick

    @Override
    public void updateEntity() {
        if (worldObj.isRemote) return;

        Block b = getBlockType();
        if (!(b instanceof BlockOreFarm)) return;
        BlockOreFarm farm = (BlockOreFarm) b;

        if (level < 0) {                       // farm from the old version: its tier was stored in the metadata
            level = getLevel();
            showStage();
            markDirty();
        }

        if (bufferCount < MAX_BUFFER) {
            float baseTicks = farm.getBaseTicks();
            progress += SPEED[level];
            int made = 0;
            while (progress >= baseTicks && bufferCount < MAX_BUFFER && made < 64) {
                progress -= baseTicks;
                makeOre(farm);
                made++;
            }
            if (made > 0) markDirty();
        }

        // Try to push stored items out twice a second (spread out so farms don't all fire together)
        if (bufferCount > 0 && (worldObj.getTotalWorldTime() + xCoord + zCoord) % 10L == 0L) {
            pushOut();
        }
    }

    /** One "mining" of the farm's ore. */
    private void makeOre(BlockOreFarm farm) {
        int fortune = FORTUNE[level];
        ArrayList<ItemStack> drops = farm.getOre().getDrops(worldObj, xCoord, yCoord, zCoord, 0, fortune);
        for (ItemStack drop : drops) {
            addToBuffer(smeltIfNeeded(farm.getOre(), drop, fortune));
        }
    }

    /** Ores that drop themselves (iron, gold) are turned into their ingots right away. */
    private ItemStack smeltIfNeeded(Block ore, ItemStack drop, int fortune) {
        if (!AUTO_SMELT || drop == null || drop.stackSize <= 0) return drop;
        if (drop.getItem() != Item.getItemFromBlock(ore)) return drop;   // coal, diamond, etc. are already finished items

        ItemStack smelted = FurnaceRecipes.smelting().getSmeltingResult(drop);
        if (smelted == null) return drop;

        int amount = drop.stackSize * smelted.stackSize;
        if (FORTUNE_BOOSTS_INGOTS && fortune > 0) {
            // same maths vanilla uses for Fortune on ores that drop a different item
            amount *= Math.max(0, worldObj.rand.nextInt(fortune + 2) - 1) + 1;
        }
        ItemStack result = smelted.copy();
        result.stackSize = amount;
        return result;
    }

    // ------------------------------------------------------------------- buffer

    private void addToBuffer(ItemStack drop) {
        if (drop == null || drop.stackSize <= 0) return;
        if (bufferType == null) {
            bufferType = drop.copy();
            bufferType.stackSize = 1;
            bufferCount = 0;
        }
        if (bufferType.isItemEqual(drop) && ItemStack.areItemStackTagsEqual(bufferType, drop)) {
            bufferCount = Math.min(MAX_BUFFER, bufferCount + drop.stackSize);
        }
    }

    /** Hand stored items to a player. Returns how many were given. */
    public int giveTo(EntityPlayer player) {
        int total = 0;
        while (bufferType != null && bufferCount > 0) {
            int take = Math.min(bufferCount, bufferType.getMaxStackSize());
            ItemStack out = bufferType.copy();
            out.stackSize = take;
            player.inventory.addItemStackToInventory(out);
            int moved = take - out.stackSize;
            if (moved <= 0) break;
            bufferCount -= moved;
            total += moved;
            if (out.stackSize > 0) break;   // player's inventory is full
        }
        if (bufferCount <= 0) {
            bufferCount = 0;
            bufferType = null;
        }
        if (total > 0) markDirty();
        return total;
    }

    /** Spill everything stored as item entities (used when the block is broken). */
    public void dropBuffer() {
        if (worldObj == null || worldObj.isRemote) return;
        while (bufferType != null && bufferCount > 0) {
            int n = Math.min(bufferCount, bufferType.getMaxStackSize());
            ItemStack stack = bufferType.copy();
            stack.stackSize = n;
            worldObj.spawnEntityInWorld(
                    new EntityItem(worldObj, xCoord + 0.5D, yCoord + 0.5D, zCoord + 0.5D, stack));
            bufferCount -= n;
        }
        bufferCount = 0;
        bufferType = null;
    }

    public String statusLine() {
        Block b = getBlockType();
        if (!(b instanceof BlockOreFarm)) return "";
        BlockOreFarm farm = (BlockOreFarm) b;
        int lvl = getLevel();
        float seconds = secondsPerOre(farm.getBaseTicks(), lvl);
        String stored = bufferCount >= MAX_BUFFER ? bufferCount + " (FULL)" : String.valueOf(bufferCount);
        return EnumChatFormatting.GOLD + farm.getDisplayName() + " Farm" + EnumChatFormatting.GRAY
                + " | Upgrade " + lvl + "/" + MAX_LEVEL
                + " | Fortune " + FORTUNE[lvl]
                + " | every " + String.format("%.2f", seconds) + "s"
                + " | Stored: " + stored;
    }

    // ------------------------------------------------------------------- output

    private void pushOut() {
        if (bufferType == null || bufferCount <= 0) return;
        boolean changed = false;

        for (ForgeDirection dir : ForgeDirection.VALID_DIRECTIONS) {
            if (bufferCount <= 0) break;
            int nx = xCoord + dir.offsetX;
            int ny = yCoord + dir.offsetY;
            int nz = zCoord + dir.offsetZ;
            if (!worldObj.blockExists(nx, ny, nz)) continue;

            TileEntity te = worldObj.getTileEntity(nx, ny, nz);
            if (!(te instanceof IInventory)) continue;

            IInventory inv = resolve(te);
            int side = dir.getOpposite().ordinal();   // the face of that inventory touching us

            while (bufferCount > 0) {
                int take = Math.min(bufferCount, bufferType.getMaxStackSize());
                ItemStack stack = bufferType.copy();
                stack.stackSize = take;
                ItemStack left = insert(inv, stack, side);
                int moved = take - (left == null ? 0 : left.stackSize);
                if (moved <= 0) break;
                bufferCount -= moved;
                changed = true;
                if (left != null) break;            // that inventory is full
            }
        }

        if (bufferCount <= 0) {
            bufferCount = 0;
            bufferType = null;
        }
        if (changed) markDirty();
    }

    /** Treat the two halves of a double chest as one inventory. */
    private IInventory resolve(TileEntity te) {
        if (te instanceof TileEntityChest) {
            ForgeDirection[] horizontal = {
                ForgeDirection.NORTH, ForgeDirection.SOUTH, ForgeDirection.WEST, ForgeDirection.EAST
            };
            for (ForgeDirection d : horizontal) {
                int ox = te.xCoord + d.offsetX;
                int oz = te.zCoord + d.offsetZ;
                if (!worldObj.blockExists(ox, te.yCoord, oz)) continue;
                TileEntity other = worldObj.getTileEntity(ox, te.yCoord, oz);
                if (other instanceof TileEntityChest && other.getBlockType() == te.getBlockType()) {
                    return new InventoryLargeChest("container.chestDouble",
                            (TileEntityChest) te, (TileEntityChest) other);
                }
            }
        }
        return (IInventory) te;
    }

    /** Insert as much of the stack as fits. Returns the leftover (or null if it all fit). */
    private static ItemStack insert(IInventory inv, ItemStack stack, int side) {
        ISidedInventory sided = inv instanceof ISidedInventory ? (ISidedInventory) inv : null;

        int[] slots;
        if (sided != null) {
            slots = sided.getAccessibleSlotsFromSide(side);
        } else {
            slots = new int[inv.getSizeInventory()];
            for (int i = 0; i < slots.length; i++) slots[i] = i;
        }

        for (int slot : slots) {
            if (stack.stackSize <= 0) return null;
            if (!inv.isItemValidForSlot(slot, stack)) continue;
            if (sided != null && !sided.canInsertItem(slot, stack, side)) continue;

            ItemStack existing = inv.getStackInSlot(slot);
            int limit = Math.min(inv.getInventoryStackLimit(), stack.getMaxStackSize());

            if (existing == null) {
                int put = Math.min(limit, stack.stackSize);
                ItemStack placed = stack.copy();
                placed.stackSize = put;
                inv.setInventorySlotContents(slot, placed);
                stack.stackSize -= put;
                inv.markDirty();
            } else if (existing.isItemEqual(stack) && ItemStack.areItemStackTagsEqual(existing, stack)) {
                int put = Math.min(limit - existing.stackSize, stack.stackSize);
                if (put > 0) {
                    existing.stackSize += put;
                    stack.stackSize -= put;
                    inv.markDirty();
                }
            }
        }
        return stack.stackSize > 0 ? stack : null;
    }

    // ---------------------------------------------------------------------- NBT

    @Override
    public void readFromNBT(NBTTagCompound tag) {
        super.readFromNBT(tag);
        level = tag.hasKey("Level") ? clampLevel(tag.getInteger("Level")) : -1;
        progress = tag.getFloat("Progress");
        bufferCount = tag.getInteger("Count");
        bufferType = tag.hasKey("Item") ? ItemStack.loadItemStackFromNBT(tag.getCompoundTag("Item")) : null;
        if (bufferType == null) bufferCount = 0;
    }

    @Override
    public void writeToNBT(NBTTagCompound tag) {
        super.writeToNBT(tag);
        if (level >= 0) tag.setInteger("Level", level);
        tag.setFloat("Progress", progress);
        tag.setInteger("Count", bufferCount);
        if (bufferType != null) {
            NBTTagCompound item = new NBTTagCompound();
            bufferType.writeToNBT(item);
            tag.setTag("Item", item);
        }
    }
}
