ORE FARM v3 (Minecraft 1.7.10 Forge)

WHAT'S NEW IN v3
1. No smelting needed: Iron and Gold farms now hand out ingots directly
   (Fortune multiplies them too).
2. 25 upgrades per farm (was 4). One Farm Core = one level.
   Level 0 = freshly crafted farm, level 25 = maxed out.
   25 Farm Cores cost 25 diamonds + 100 gold ingots + 100 redstone in total.
3. Miner's Pickaxe: every player is given one the first time they join a world.
   Diamond tier, Fortune V, Efficiency X, never breaks, mines a 3x3 area
   (the flat 3x3 square facing you; only stone-type blocks it can harvest).
   Hold SNEAK to mine a single block.

SETUP
1. Copy this zip's "src" folder into your mod project's "src" folder (merge/replace).
   Nothing needs deleting. New files: ItemMinerPickaxe.java, StarterGearHandler.java.
2. Build and run. The jar ends up wherever your project builds it (usually build/libs).
   Farms and items from v2 keep working: an old tier 1-5 farm becomes level 0-4.

FARMS (one block each): Coal, Iron, Gold, Redstone, Lapis, Diamond, Emerald
- Make the ore's normal drops on a timer (Fortune counts). Iron/Gold come out as ingots.
- Push items into any touching chest / double chest / hopper / furnace.
- Hold up to 2048 items inside. Empty-hand right-click = take items. Sneak + empty hand = info only.
- Breaking a farm drops its stored items and the farm keeps its level.

FARM CORE: right-click a farm with it (don't sneak) to upgrade one level.

LEVEL   SPEED    FORTUNE
  0     1.0x     0
  1     1.5x     0
  2     2.5x     I
  3     4.0x     II
  4     6.0x     III
 5-25   +1.5x per level, +1 Fortune every 3 levels
 10     15x      V
 25     37.5x    X

Base speed per ore (level 0): Coal 5s, Iron 7s, Gold 10s, Redstone 8s, Lapis 8s, Diamond 20s, Emerald 30s.
Farm textures: 5 pictures per farm, spread over the levels
(0 = t1, 1-6 = t2, 7-12 = t3, 13-18 = t4, 19-25 = t5).
All 36 images (35 farm blocks + Farm Core) are 64x64, redrawn from the old 16x16 ones.
The Miner's Pickaxe uses the normal vanilla diamond pickaxe picture.

RECIPES
Farm Core:  G R G / R D R / G R G   (G gold ingot, R redstone, D diamond)
Any farm:   I H I / M R M / I M I   (I iron ingot, H hopper, R redstone, M = the ore's item:
            coal / iron ingot / gold ingot / redstone / lapis / diamond / emerald)

TESTING / COMMANDS
/give @p orefarm:coal_farm 1 25     max-level farm (the last number is the level; also: iron_farm, gold_farm,
                                    redstone_farm, lapis_farm, diamond_farm, emerald_farm)
/give @p orefarm:farm_core 64       Farm Cores
/give @p orefarm:miner_pickaxe 1 0 {ench:[{id:35,lvl:5},{id:32,lvl:10}]}    spare pickaxe
The creative menu also has a level 0 and a level 25 version of every farm, and the enchanted pickaxe (Tools tab).

TWEAK
OreFarmMod.java      -> baseTicks.
TileOreFarm.java     -> the static block at the top (SPEED / FORTUNE per level), MAX_BUFFER,
                        AUTO_SMELT, FORTUNE_BOOSTS_INGOTS.
ItemMinerPickaxe.java -> FORTUNE_LEVEL, EFFICIENCY_LEVEL.
